﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSV_Reader
{
    public class BivariateNumericObservation
    {
        public double X;
        public double Y;
    }
}
