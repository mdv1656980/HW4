﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSV_Reader
{
    public class Interval
    {
        public double LowerEnd;
        public double UpperEnd;

        public bool ContainsValue(double v)
        {
            return v > LowerEnd && v <= UpperEnd;
        }
    }
}
