﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSV_Reader

{
    class CSVOptions
    {
        //default values
        private bool hasNameOfFields = true;
        private bool fieldsInQuotes = true;
        private string[] delimiters = new string[] { "," };
        private string[] commentTags = new string[] { "#" };

        public bool GetHasNameOfFields()
        {
            return this.hasNameOfFields;
        }

        public bool GetFieldsInQuotes()
        {
            return this.fieldsInQuotes;
        }

        public string[] GetDelimiters()
        {
            return this.delimiters;
        }

        public string[] GetCommentTags()
        {
            return this.commentTags;
        }

        public void SetHasNameOfFields(bool hnof)
        {
            this.hasNameOfFields = hnof;
        }

        public void SetFieldsInQuotes(bool fiq)
        {
            this.fieldsInQuotes = fiq;
        }

        public void SetDelimiters(string delimiters)
        {
            this.delimiters = delimiters.Split(' ');
        }

        public void SetCommentTags(string commentTags)
        {
            this.commentTags = commentTags.Split(' ');
        }
    }
}


//nameOfVariablesLine = tfp.ReadLine(); //TODO: Eh, bella domanda ....
//tfp.TextFieldType = FieldType.Delimited;
//tfp.Delimiters = new string[] { "," };
//tfp.HasFieldsEnclosedInQuotes = true;
//tfp.CommentTokens = new string[] { "#" };