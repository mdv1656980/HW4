﻿namespace CSV_Reader
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.fiqGroupBox = new System.Windows.Forms.GroupBox();
            this.noFiqRadioButton = new System.Windows.Forms.RadioButton();
            this.yesFiqRadioButton = new System.Windows.Forms.RadioButton();
            this.novGroubBox = new System.Windows.Forms.GroupBox();
            this.noNovRadioButton = new System.Windows.Forms.RadioButton();
            this.yesNovRadioButton = new System.Windows.Forms.RadioButton();
            this.commentTokenTextBox = new System.Windows.Forms.TextBox();
            this.delimitersTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.fieldsListView = new System.Windows.Forms.ListView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.domainUpDownX = new System.Windows.Forms.DomainUpDown();
            this.domainUpDownY = new System.Windows.Forms.DomainUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.graphStartButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.startingPointY = new System.Windows.Forms.TextBox();
            this.startingPointX = new System.Windows.Forms.TextBox();
            this.intervalSizeY = new System.Windows.Forms.TextBox();
            this.intervalSizeX = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.contingencyTableButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.fiqGroupBox.SuspendLayout();
            this.novGroubBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "CSV Reader";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 43);
            this.button1.TabIndex = 1;
            this.button1.Text = "Load CSV File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(16, 262);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 43);
            this.button2.TabIndex = 2;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(16, 68);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(387, 20);
            this.textBox1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Load a CSV file";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(16, 175);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 43);
            this.button3.TabIndex = 6;
            this.button3.Text = "Read Selected File";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(784, 68);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(182, 245);
            this.treeView1.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fiqGroupBox);
            this.groupBox1.Controls.Add(this.novGroubBox);
            this.groupBox1.Controls.Add(this.commentTokenTextBox);
            this.groupBox1.Controls.Add(this.delimitersTextBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(106, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 215);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CSV Options";
            // 
            // fiqGroupBox
            // 
            this.fiqGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fiqGroupBox.Controls.Add(this.noFiqRadioButton);
            this.fiqGroupBox.Controls.Add(this.yesFiqRadioButton);
            this.fiqGroupBox.Location = new System.Drawing.Point(10, 87);
            this.fiqGroupBox.Name = "fiqGroupBox";
            this.fiqGroupBox.Size = new System.Drawing.Size(277, 52);
            this.fiqGroupBox.TabIndex = 9;
            this.fiqGroupBox.TabStop = false;
            this.fiqGroupBox.Text = "Fields In Quotes";
            // 
            // noFiqRadioButton
            // 
            this.noFiqRadioButton.AutoSize = true;
            this.noFiqRadioButton.Location = new System.Drawing.Point(109, 20);
            this.noFiqRadioButton.Name = "noFiqRadioButton";
            this.noFiqRadioButton.Size = new System.Drawing.Size(39, 17);
            this.noFiqRadioButton.TabIndex = 1;
            this.noFiqRadioButton.TabStop = true;
            this.noFiqRadioButton.Text = "No";
            this.noFiqRadioButton.UseVisualStyleBackColor = true;
            // 
            // yesFiqRadioButton
            // 
            this.yesFiqRadioButton.AutoSize = true;
            this.yesFiqRadioButton.Location = new System.Drawing.Point(7, 20);
            this.yesFiqRadioButton.Name = "yesFiqRadioButton";
            this.yesFiqRadioButton.Size = new System.Drawing.Size(43, 17);
            this.yesFiqRadioButton.TabIndex = 0;
            this.yesFiqRadioButton.TabStop = true;
            this.yesFiqRadioButton.Text = "Yes";
            this.yesFiqRadioButton.UseVisualStyleBackColor = true;
            // 
            // novGroubBox
            // 
            this.novGroubBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.novGroubBox.Controls.Add(this.noNovRadioButton);
            this.novGroubBox.Controls.Add(this.yesNovRadioButton);
            this.novGroubBox.Location = new System.Drawing.Point(9, 35);
            this.novGroubBox.Name = "novGroubBox";
            this.novGroubBox.Size = new System.Drawing.Size(278, 46);
            this.novGroubBox.TabIndex = 8;
            this.novGroubBox.TabStop = false;
            this.novGroubBox.Text = "Name Of Variables On First Line";
            // 
            // noNovRadioButton
            // 
            this.noNovRadioButton.AutoSize = true;
            this.noNovRadioButton.Location = new System.Drawing.Point(109, 20);
            this.noNovRadioButton.Name = "noNovRadioButton";
            this.noNovRadioButton.Size = new System.Drawing.Size(39, 17);
            this.noNovRadioButton.TabIndex = 1;
            this.noNovRadioButton.TabStop = true;
            this.noNovRadioButton.Text = "No";
            this.noNovRadioButton.UseVisualStyleBackColor = true;
            // 
            // yesNovRadioButton
            // 
            this.yesNovRadioButton.AutoSize = true;
            this.yesNovRadioButton.Location = new System.Drawing.Point(7, 20);
            this.yesNovRadioButton.Name = "yesNovRadioButton";
            this.yesNovRadioButton.Size = new System.Drawing.Size(43, 17);
            this.yesNovRadioButton.TabIndex = 0;
            this.yesNovRadioButton.TabStop = true;
            this.yesNovRadioButton.Text = "Yes";
            this.yesNovRadioButton.UseVisualStyleBackColor = true;
            // 
            // commentTokenTextBox
            // 
            this.commentTokenTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.commentTokenTextBox.Location = new System.Drawing.Point(98, 189);
            this.commentTokenTextBox.Name = "commentTokenTextBox";
            this.commentTokenTextBox.Size = new System.Drawing.Size(189, 20);
            this.commentTokenTextBox.TabIndex = 7;
            // 
            // delimitersTextBox
            // 
            this.delimitersTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.delimitersTextBox.Location = new System.Drawing.Point(98, 160);
            this.delimitersTextBox.Name = "delimitersTextBox";
            this.delimitersTextBox.Size = new System.Drawing.Size(189, 20);
            this.delimitersTextBox.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Delimiters";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Comment Token";
            // 
            // fieldsListView
            // 
            this.fieldsListView.HideSelection = false;
            this.fieldsListView.Location = new System.Drawing.Point(12, 318);
            this.fieldsListView.Name = "fieldsListView";
            this.fieldsListView.Size = new System.Drawing.Size(954, 141);
            this.fieldsListView.TabIndex = 9;
            this.fieldsListView.UseCompatibleStateImageBehavior = false;
            this.fieldsListView.View = System.Windows.Forms.View.SmallIcon;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Location = new System.Drawing.Point(14, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(320, 277);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.Location = new System.Drawing.Point(14, 319);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(320, 302);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(986, 706);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(320, 283);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // domainUpDownX
            // 
            this.domainUpDownX.Location = new System.Drawing.Point(13, 47);
            this.domainUpDownX.Name = "domainUpDownX";
            this.domainUpDownX.Size = new System.Drawing.Size(144, 20);
            this.domainUpDownX.TabIndex = 18;
            // 
            // domainUpDownY
            // 
            this.domainUpDownY.Location = new System.Drawing.Point(198, 47);
            this.domainUpDownY.Name = "domainUpDownY";
            this.domainUpDownY.Size = new System.Drawing.Size(148, 20);
            this.domainUpDownY.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "X Variable";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(230, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "Y Variable";
            // 
            // graphStartButton
            // 
            this.graphStartButton.Location = new System.Drawing.Point(9, 136);
            this.graphStartButton.Name = "graphStartButton";
            this.graphStartButton.Size = new System.Drawing.Size(351, 49);
            this.graphStartButton.TabIndex = 22;
            this.graphStartButton.Text = "Draw Plots";
            this.graphStartButton.UseVisualStyleBackColor = true;
            this.graphStartButton.Click += new System.EventHandler(this.graphStartButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.contingencyTableButton);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.startingPointY);
            this.panel1.Controls.Add(this.domainUpDownX);
            this.panel1.Controls.Add(this.startingPointX);
            this.panel1.Controls.Add(this.graphStartButton);
            this.panel1.Controls.Add(this.intervalSizeY);
            this.panel1.Controls.Add(this.intervalSizeX);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.domainUpDownY);
            this.panel1.Location = new System.Drawing.Point(409, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(369, 244);
            this.panel1.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(195, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "y interval size";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(195, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "y starting point";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "x starting point";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 28;
            this.label7.Text = "x interval size";
            // 
            // startingPointY
            // 
            this.startingPointY.Location = new System.Drawing.Point(276, 107);
            this.startingPointY.Name = "startingPointY";
            this.startingPointY.Size = new System.Drawing.Size(70, 20);
            this.startingPointY.TabIndex = 27;
            // 
            // startingPointX
            // 
            this.startingPointX.Location = new System.Drawing.Point(81, 107);
            this.startingPointX.Name = "startingPointX";
            this.startingPointX.Size = new System.Drawing.Size(76, 20);
            this.startingPointX.TabIndex = 26;
            // 
            // intervalSizeY
            // 
            this.intervalSizeY.Location = new System.Drawing.Point(276, 81);
            this.intervalSizeY.Name = "intervalSizeY";
            this.intervalSizeY.Size = new System.Drawing.Size(70, 20);
            this.intervalSizeY.TabIndex = 25;
            // 
            // intervalSizeX
            // 
            this.intervalSizeX.Location = new System.Drawing.Point(81, 81);
            this.intervalSizeX.Name = "intervalSizeX";
            this.intervalSizeX.Size = new System.Drawing.Size(76, 20);
            this.intervalSizeX.TabIndex = 24;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 465);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(954, 537);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.Text = "dataGridView1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(972, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(348, 936);
            this.panel2.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1119, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 17);
            this.label11.TabIndex = 26;
            this.label11.Text = "Plots";
            // 
            // contingencyTableButton
            // 
            this.contingencyTableButton.Location = new System.Drawing.Point(9, 191);
            this.contingencyTableButton.Name = "contingencyTableButton";
            this.contingencyTableButton.Size = new System.Drawing.Size(351, 49);
            this.contingencyTableButton.TabIndex = 32;
            this.contingencyTableButton.Text = "Show Contingency Table";
            this.contingencyTableButton.UseVisualStyleBackColor = true;
            this.contingencyTableButton.Click += new System.EventHandler(this.contingencyTableButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1329, 1014);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.fieldsListView);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.MaximumSize = new System.Drawing.Size(1345, 1053);
            this.MinimumSize = new System.Drawing.Size(1345, 1038);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.fiqGroupBox.ResumeLayout(false);
            this.fiqGroupBox.PerformLayout();
            this.novGroubBox.ResumeLayout(false);
            this.novGroubBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox commentTokenTextBox;
        private System.Windows.Forms.TextBox delimitersTextBox;
        private System.Windows.Forms.GroupBox fiqGroupBox;
        private System.Windows.Forms.RadioButton noFiqRadioButton;
        private System.Windows.Forms.RadioButton yesFiqRadioButton;
        private System.Windows.Forms.GroupBox novGroubBox;
        private System.Windows.Forms.RadioButton noNovRadioButton;
        private System.Windows.Forms.RadioButton yesNovRadioButton;
        private System.Windows.Forms.ListView fieldsListView;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.DomainUpDown domainUpDownX;
        private System.Windows.Forms.DomainUpDown domainUpDownY;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button graphStartButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox startingPointY;
        private System.Windows.Forms.TextBox startingPointX;
        private System.Windows.Forms.TextBox intervalSizeY;
        private System.Windows.Forms.TextBox intervalSizeX;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button contingencyTableButton;
    }
}

