﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Globalization;

namespace CSV_Reader
{
    public partial class Form1 : Form
    {
        Color[] colors = { Color.Blue, Color.Red, Color.Green, Color.Purple, Color.Aquamarine, Color.Brown, Color.Orange, Color.Cyan, Color.Magenta, Color.Lavender, Color.Coral };
        DataTable dt;
        int x_intervalsNumber;
        int y_intervalsNumber;
        Dictionary<Tuple<Interval, Interval>, FrequenciesForValue> bivariateDistribution;

        enum dataType
        {
            System_Boolean = 0,
            System_Int32 = 1,
            System_Int64 = 2,
            System_Double = 3,
            System_DateTime = 4,
            System_String = 5
        }

        public Form1()
        {
            InitializeComponent() ;
        }




        private bool SelectFileFromDialog()
        {
            var dialog = new OpenFileDialog();
            dialog.ShowDialog();

            if (string.IsNullOrWhiteSpace(dialog.FileName) || System.IO.Path.GetExtension(dialog.FileName) != ".csv")
            {
                MessageBox.Show("Please, select a CSV file first ...", "No CSV Selected",  MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                this.textBox1.Text = dialog.FileName;
                return true;
            }
        }




        /* LOAD FILE BUTTON HANDLER */
        private void Button1_Click(object sender, EventArgs e)
        {
            SelectFileFromDialog();
        }






        /* CLEAR BUTTON HANDLER*/
        private void Button2_Click(object sender, EventArgs e)
        {
            this.textBox1.Clear();
            this.fieldsListView.Clear();
            this.treeView1.Nodes.Clear();
            this.domainUpDownX.Items.Clear();
        }





        /* SETTING OPTIONS */
        private void setOptions(CSVOptions csvo)
        {
            if(this.yesNovRadioButton.Checked)
            {
                csvo.SetHasNameOfFields(true);
            }
            else if(this.noNovRadioButton.Checked)
            {
                csvo.SetHasNameOfFields(false);
            }

            if(this.yesFiqRadioButton.Checked)
            {
                csvo.SetFieldsInQuotes(true);
            }
            else if(this.noFiqRadioButton.Checked)
            {
                csvo.SetFieldsInQuotes(false);
            }

            if(!String.IsNullOrEmpty(this.delimitersTextBox.Text))
            {
                csvo.SetDelimiters(this.delimitersTextBox.Text);
            }

            if (!String.IsNullOrEmpty(this.commentTokenTextBox.Text))
            {
                csvo.SetCommentTags(this.commentTokenTextBox.Text);
            } 
        }



        /* PARSE VALUE */
        private dataType ParseValue(string str)
        {

            bool boolValue;
            Int32 intValue;
            Int64 bigintValue;
            double doubleValue;
            DateTime dateValue;

            if (bool.TryParse(str, out boolValue))
                return dataType.System_Boolean;
            else if (Int32.TryParse(str, out intValue))
                return dataType.System_Int32;
            else if (Int64.TryParse(str, out bigintValue))
                return dataType.System_Int64;
            else if (double.TryParse(str, out doubleValue))
                return dataType.System_Double;
            else if (DateTime.TryParse(str, out dateValue))
                return dataType.System_DateTime;
            else return dataType.System_String;

        }



        List<string[]> fieldsOfRows;
        /* READ FILE BUTTON HANDLER*/
        private void Button3_Click(object sender, EventArgs e)
        {

            this.treeView1.Nodes.Clear();
            string Path = this.textBox1.Text.Trim();
            domainUpDownX.Items.Clear();

            InitializeGraphics();
            
            if (String.IsNullOrEmpty(Path))
            {
                MessageBox.Show("Please, select a CSV file first ...", "Invalid File", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (var tfp = new TextFieldParser(Path))
                {
                    
                    //setting options
                    CSVOptions csvo = new CSVOptions();
                    setOptions(csvo);

                    //configuring tfp
                    tfp.TextFieldType = FieldType.Delimited;
                    tfp.Delimiters = csvo.GetDelimiters();
                    tfp.HasFieldsEnclosedInQuotes = csvo.GetFieldsInQuotes();
                    tfp.CommentTokens = csvo.GetCommentTags();

                    //initializing data table
                    dt = new DataTable("Data");
                    this.dataGridView1.DataSource = dt;

                    //setting name of fields
                    string[] nameOfFields;
                    if (csvo.GetHasNameOfFields())
                    {
                        nameOfFields = tfp.ReadFields();
                        foreach(string field in nameOfFields)
                        {
                            domainUpDownX.Items.Add(field);
                            domainUpDownY.Items.Add(field);
                            dt.Columns.Add(field);
                        }
                    }
                    else 
                    {
                        //automatically assign field names
                        StreamReader sr = new StreamReader(Path);
                        string firstLine = sr.ReadLine();
                        int numberOfColumns = firstLine.Split(',').Length;
                        sr.Dispose();
                        nameOfFields = new string[numberOfColumns];
                        int j;
                        for(j = 0; j < numberOfColumns; j++)
                        {
                            nameOfFields[j] = "Field" + (j+1);
                            //this.fieldsListView.Columns.Add(nameOfFields[j]);
                            domainUpDownX.Items.Add(nameOfFields[j]); 
                            domainUpDownY.Items.Add(nameOfFields[j]);
                            dt.Columns.Add(nameOfFields[j]);
                        }
                    }

                    // array of line of fields
                    fieldsOfRows = new List<string[]>();

                    this.treeView1.BeginUpdate();
                    int i = 0;
                    do
                    {
                        if (tfp.EndOfData)
                            break;

                        try
                        {
                            // splitting into an array of strings'
                            string[] lineFields = tfp.ReadFields();

                            //saving fields array for further computations on fields
                            fieldsOfRows.Add(lineFields);
                            
                            int j = 0;
                            this.fieldsListView.Items.Add("[ ROW " + (i+1) + "]");
                            this.treeView1.Nodes.Add("Row " + (i + 1));
                            foreach (string field in lineFields)
                            {
                                // populating tree view
                                this.treeView1.Nodes[i].Nodes.Add(nameOfFields[j] + "   :   " + field);

                                //identifying data types
                                bool boolValue;
                                Int32 intValue;
                                Int64 bigintValue;
                                double doubleValue;
                                DateTime dateValue;
                                string typeString = "";

                                int datatype = (int)ParseValue(field);
                                switch (datatype)
                                {
                                    case 0: //bool
                                        bool.TryParse(field, out boolValue);
                                        typeString = "Boolean";
                                        break;
                                    case 1: //int32
                                        Int32.TryParse(field, out intValue);
                                        typeString = "Int32";
                                        break;
                                    case 2: //int64
                                        Int64.TryParse(field, out bigintValue);
                                        typeString = "Int64";
                                        break;
                                    case 3: //double
                                        double.TryParse(field, out doubleValue);
                                        typeString = "Double";
                                        break;
                                    case 4: //date
                                        DateTime.TryParse(field, out dateValue);
                                        typeString = "Date";
                                        break;
                                    case 5: //string
                                        typeString = "String";
                                        break;
                                }

                                this.fieldsListView.Items.Add("FIELD: " + nameOfFields[j] + " -> " + "TYPE: " + typeString + " -> VALUE: " + field);

                                //adding row to DataTable
                                populateDataTable(lineFields);

                                j++;
                            }
                            i++;

                        }
                        catch (MalformedLineException ex)
                        {
                            // log ex.Message
                            MessageBox.Show("Malfromed CSV file, check line " + (i+1), "Malformed CSV", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        } 
                    }
                    while (true);

                    this.treeView1.EndUpdate();
                    i = 0;
                    tfp.Dispose(); //makes the file available to other programs explicitly if you use Dim instead of Using 
                    
                }
            }

        }


        // Adds a row to a data table
        private void populateDataTable(string[] fields)
        {
            DataRow dr = dt.NewRow();
            for (int k = 0; k < fields.Count(); k++)
            {
                dr[k] = fields[k];
            }
            dt.Rows.Add(dr); //add row
        }


        private void graphStartButton_Click(object sender, EventArgs e)
        {
            //List<BivariateNumericObservation> ListOfObservations, double IntervalSize_X, double IntervalSize_Y, double StartingEndPoint_X, double StartingEndPoint_Y

            List<BivariateNumericObservation> listOfObservations = new List<BivariateNumericObservation>();
            List<double> listOfObservationsX = new List<double>();
            List<double> listOfObservationsY = new List<double>();
            double x_intervalSize;
            double y_intervalSize;
            double x_startingEndPoint;
            double y_startingEndPoint;

            int x_index = this.domainUpDownX.SelectedIndex;
            int y_index = this.domainUpDownY.SelectedIndex;
            
            foreach (string[] fieldsOfLine in fieldsOfRows)
            {
                BivariateNumericObservation obs = new BivariateNumericObservation();
                double xvar;
                double yvar;
                Int64 xvar_int;
                Int64 yvar_int;
                if (double.TryParse(fieldsOfLine[x_index], out xvar) && double.TryParse(fieldsOfLine[y_index], out yvar))
                {
                    obs.X = xvar;
                    obs.Y = yvar;
                    listOfObservations.Add(obs);
                    listOfObservationsX.Add(xvar);
                    listOfObservationsY.Add(yvar);    
                } else if (Int64.TryParse(fieldsOfLine[x_index], out xvar_int) && Int64.TryParse(fieldsOfLine[y_index], out yvar_int))
                {
                    obs.X = (double)xvar_int;
                    obs.Y = (double)yvar_int;
                    listOfObservations.Add(obs);
                    listOfObservationsX.Add((double)xvar_int);
                    listOfObservationsY.Add((double)yvar_int);
                } 
                else
                {
                    MessageBox.Show("Please, select numerical variables!", "Invalid Variables", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            double.TryParse(intervalSizeX.Text, out x_intervalSize);
            double.TryParse(intervalSizeY.Text, out y_intervalSize);
            double.TryParse(startingPointX.Text, out x_startingEndPoint);
            double.TryParse(startingPointY.Text, out y_startingEndPoint);

            bivariateDistribution = BivariateDistribution_ContinuousVariable(
                listOfObservations, x_intervalSize, y_intervalSize, x_startingEndPoint, y_startingEndPoint);

            Dictionary<Interval, FrequenciesForValue> univariateDistributionX = UnivariateDistribution_ContinuousVariable(
                listOfObservationsX, x_intervalSize, x_startingEndPoint);

            Dictionary<Interval, FrequenciesForValue> univariateDistributionY = UnivariateDistribution_ContinuousVariable(
                listOfObservationsY, y_intervalSize, y_startingEndPoint);

            DrawScatterPlot(listOfObservations, scatterplotBitmap, scatterplotGraphics, pictureBox1);
            DrawHistogram(univariateDistributionX, xHistogramBitmap, xHistogramGraphics, pictureBox2);
            DrawHistogram(univariateDistributionY, yHistogramBitmap, yHistogramGraphics, pictureBox3);

        }


        



        /* FIND INTERVAL FOR THE PASSED VALUE */
        public Interval FindIntervalForValue(double v, double IntervalSize, ref List<Interval> ListOfIntervals)
        {
            foreach (var Interval in ListOfIntervals)
            {
                if (Interval.ContainsValue(v))
                    return Interval;
            }

            if (v <= ListOfIntervals[0].LowerEnd)
            {
                do
                {
                    var NewLeftInterval = new Interval();
                    NewLeftInterval.UpperEnd = ListOfIntervals[0].LowerEnd;
                    NewLeftInterval.LowerEnd = NewLeftInterval.UpperEnd - IntervalSize;
                    ListOfIntervals.Insert(0, NewLeftInterval);
                    if (NewLeftInterval.ContainsValue(v))
                        return NewLeftInterval;
                }
                while (true);
            }
            else if (v > ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd)
            {
                do
                {
                    var NewRightInterval = new Interval();
                    NewRightInterval.LowerEnd = ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd;
                    NewRightInterval.UpperEnd = NewRightInterval.LowerEnd + IntervalSize;
                    ListOfIntervals.Add(NewRightInterval);
                    if (NewRightInterval.ContainsValue(v))
                        return NewRightInterval;
                }
                while (true);
            }

            return default;
        }



        /* COMPUTES THE BIVARIATE FREQUENCY DISTRIBUTION */
        public Dictionary<Tuple<Interval, Interval>, FrequenciesForValue> BivariateDistribution_ContinuousVariable(List<BivariateNumericObservation> ListOfObservations, double IntervalSize_X, double IntervalSize_Y, double StartingEndPoint_X, double StartingEndPoint_Y)
        {
            var FrequencyDistribution = new Dictionary<Tuple<Interval, Interval>, FrequenciesForValue>();
            // First interval for X'

            var Interval_X_0 = new Interval();
            Interval_X_0.LowerEnd = StartingEndPoint_X;
            Interval_X_0.UpperEnd = Interval_X_0.LowerEnd + IntervalSize_X;
            var ListOfIntervals_X = new List<Interval>();
            ListOfIntervals_X.Add(Interval_X_0);

            // First interval for Y'

            var Interval_Y_0 = new Interval();
            Interval_Y_0.LowerEnd = StartingEndPoint_Y;
            Interval_Y_0.UpperEnd = Interval_Y_0.LowerEnd + IntervalSize_Y;
            var ListOfIntervals_Y = new List<Interval>();
            ListOfIntervals_Y.Add(Interval_Y_0);
            Interval Interval_Found_X;
            Interval Interval_Found_Y;
            foreach (BivariateNumericObservation b in ListOfObservations)
            {
                Interval_Found_X = null;
                Interval_Found_Y = null;
                Interval_Found_X = FindIntervalForValue(b.X, IntervalSize_X, ref ListOfIntervals_X);
                Interval_Found_Y = FindIntervalForValue(b.Y, IntervalSize_Y, ref ListOfIntervals_Y);
                var FoundTuple = new Tuple<Interval, Interval>(Interval_Found_X, Interval_Found_Y);
                if (FrequencyDistribution.ContainsKey(FoundTuple))
                {
                    FrequencyDistribution[FoundTuple].Count += 1;
                }
                else
                {
                    FrequencyDistribution.Add(FoundTuple, new FrequenciesForValue());
                }
            }

            return FrequencyDistribution;
        }


        /* COMPUTES THE UIVARIATE FREQUENCY DISTRIBUTION */
        public Dictionary<Interval, FrequenciesForValue> UnivariateDistribution_ContinuousVariable(List<double> observations, double IntervalSize, double StartingEndPoint)
        {
            var FrequencyDistribution = new Dictionary<Interval, FrequenciesForValue>();
            // First interval for X'

            var Interval_0 = new Interval();
            Interval_0.LowerEnd = StartingEndPoint;
            Interval_0.UpperEnd = Interval_0.LowerEnd + IntervalSize;
            var ListOfIntervals_X = new List<Interval>();
            ListOfIntervals_X.Add(Interval_0);

            Interval Interval_Found;

            foreach (double value in observations)
            {
                Interval_Found = null;
                
                Interval_Found = FindIntervalForValue(value, IntervalSize, ref ListOfIntervals_X);
                
                if (FrequencyDistribution.ContainsKey(Interval_Found))
                {
                    FrequencyDistribution[Interval_Found].Count += 1;
                }
                else
                {
                    FrequencyDistribution.Add(Interval_Found, new FrequenciesForValue());
                }
            }
            return FrequencyDistribution;
        }




        public Bitmap scatterplotBitmap;
        public Graphics scatterplotGraphics;
        public Bitmap xHistogramBitmap;
        public Graphics xHistogramGraphics;
        public Bitmap yHistogramBitmap;
        public Graphics yHistogramGraphics;
        public Font SmallFont = new Font("Calibri", 10f, FontStyle.Regular, GraphicsUnit.Pixel);
        // window
        public double MinX_Window = -250;
        public double MaxX_Window = 250d;
        public double MinY_Window = -250;
        public double MaxY_WIndow = 250d;
        public double RangeX;
        public double RangeY;

        public void InitializeGraphics()
        {
            //init pictureBox1
            scatterplotBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            scatterplotGraphics = Graphics.FromImage(scatterplotBitmap);
            scatterplotGraphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            scatterplotGraphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            //init pictureBox2
            xHistogramBitmap = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            xHistogramGraphics = Graphics.FromImage(xHistogramBitmap);
            xHistogramGraphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            xHistogramGraphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            //init pictureBox3
            yHistogramBitmap = new Bitmap(pictureBox3.Width, pictureBox3.Height);
            yHistogramGraphics = Graphics.FromImage(yHistogramBitmap);
            yHistogramGraphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            yHistogramGraphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

        }


        // X to x transformation
        public int X_Viewport(double X_World, Rectangle Viewport, double MinX, double RangeX)
        {
            return (int)(Viewport.Left + Viewport.Width * (X_World - MinX) / RangeX);
        }

        // Y to y transformation
        public int Y_Viewport(double Y_World, Rectangle Viewport, double MinY, double RangeY)
        {
            return (int)(Viewport.Top + Viewport.Height - Viewport.Height * (Y_World - MinY) / RangeY);
        }


        // drawing the Histogram
        void DrawHistogram(Dictionary<Interval, FrequenciesForValue> distribution, Bitmap b, Graphics g, PictureBox pb)
        {
            int max = 0;
            foreach (KeyValuePair<Interval, FrequenciesForValue> kvp in distribution)
            {
                if (distribution[kvp.Key].Count > max)
                {
                    max = distribution[kvp.Key].Count;
                }
            }
            g.Clear(Color.White);
            float slotW = pb.Width / (float)distribution.Count;
            float slotH = pb.Height / (float)max;

            int i = 0;
            foreach(KeyValuePair<Interval, FrequenciesForValue> kvp in distribution)
            {
                SolidBrush brush = new SolidBrush(colors[i%colors.Length]);
                g.FillRectangle(brush, i * slotW, pb.Height - distribution[kvp.Key].Count * slotH, slotW, distribution[kvp.Key].Count * slotH);
                i++;
            }
            //addLabel(g1, "histogram");
            pb.Image = b;
        }

        void DrawScatterPlot(List<BivariateNumericObservation> listOfObservations, Bitmap b, Graphics g, PictureBox pb)
        {
            Pen p = new Pen(Brushes.Black, 1.0f);

            // transform and prints the points
            int i = 0;
            foreach (BivariateNumericObservation obs in listOfObservations)
            {
                SolidBrush brush = new SolidBrush(colors[i % colors.Length]);
                //Coordinates (X,Y)
                double X = obs.X;
                double Y = obs.Y;
                g.FillEllipse(brush, (float)X, (float)Y, 8, 8);
                g.DrawEllipse(p, (float)X, (float)Y, 8, 8);
                i++;
            }

            //drawing grid
            //TODO: scale the grid with real dimension and add zoom and redimension functions + transformations
            for (int y = 0; y <= 20; ++y)
                g.DrawLine(p, 0, y * 40, 20 * 40, y * 40);
            for (int x = 0; x <= 20; ++x)
                g.DrawLine(p, x * 40, 0, x * 40, 20 * 40);

            pb.Image = b;

            
        }

        private void contingencyTableButton_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(bivariateDistribution);
            form2.Show();
        }
    }
}

// draw grid on the scatterplot
/*double x_max;
double y_max;
double x_intervalSize;
double y_intervalSize;

if (x_max%x_intervalSize == 0)
{
    x_intervalsNumber = (int)(x_max / x_intervalSize);
}else
{
    x_intervalsNumber = (int)(x_max / x_intervalSize)+1;
}
if (y_max % y_intervalSize == 0)
{
    y_intervalsNumber = (int)(y_max / y_intervalSize);
}
else
{
    y_intervalsNumber = (int)(y_max / y_intervalSize) + 1;
}

int cellsNumber = x_intervalsNumber * y_intervalsNumber;
int cellsSizeX = pb.Width / x_intervalsNumber;
int cellsSizeY = pb.Height / y_intervalsNumber;
for (int y = 0; y <= cellsNumber; ++y)
    g.DrawLine(p, 0, y * cellsSizeY, cellsNumber * cellsSizeY, y * cellsSizeY);
for (int x = 0; x <= cellsNumber; ++x)
    g.DrawLine(p, x * cellsSizeX, 0, x * cellsSizeX, cellsNumber * cellsSizeX);*/





/*
 SizeF MaxSizeX;
        SizeF MaxSizeY;
        SizeF MaxSize;
        ResizableRectangle R;


        private void drawContingencyTable()
        {
            g2.Clear(Color.Gainsboro);
            // g2.DrawRectangle(Pens.Red, R.R);
            // g2.FillRectangle(Brushes.Red, R.R);
            int x;
            int y;
            List<List<int>> Matrix = generateDatasetMatrix();

            // draw header for X
            for (x = 1; x <= FrequencyDistributionX.Count; x++)
            {
                g2.DrawString(FrequencyDistributionX[x - 1].printInterval(), DefaultFont, Brushes.Indigo, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win));
                // vertical lines for each column
                g2.DrawLine(Pens.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win), R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MinY_Win));
            }
            g2.DrawString("Mar Y", DefaultFont, Brushes.Indigo, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win));
            g2.DrawLine(Pens.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win), R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MinY_Win));


            for (y = 1; y <= FrequencyDistributionY.Count; y++)
            {
                // draw header for Y
                g2.DrawString(FrequencyDistributionY[y - 1].printInterval(), DefaultFont, Brushes.Black, R.viewport_X(0), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height));
                // horizontal lines for each row
                g2.DrawLine(Pens.Black, R.viewport_X(0), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height), R.viewport_X(R.R.Width), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height));

                for (x = 1; x <= FrequencyDistributionX.Count; x++)
                {
                    // joint frequency
                    g2.DrawString(Matrix[y - 1][x - 1].ToString(), DefaultFont, Brushes.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height));
                }

                // Marginal for Y (rightmost column)
                g2.DrawString(FrequencyDistributionY[y - 1].Count.ToString(), DefaultFont, Brushes.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height));
            }
            g2.DrawString("Mar X", DefaultFont, Brushes.Indigo, R.viewport_X(0), R.viewport_Y(R.MinY_Win - MaxSize.Height));
            g2.DrawLine(Pens.Black, R.viewport_X(0), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height), R.viewport_X(R.MaxX_Win), R.viewport_Y(R.MaxY_Win - y * MaxSize.Height));
            //g2.DrawLine(Pens.Black, R.viewport_X(0), R.viewport_Y(-y * MaxSize.Height), R.viewport_X(300), R.viewport_Y(-y * MaxSize.Height));

            for (x = 1; x <= FrequencyDistributionX.Count; x++)
            {
                // Marginal for X (lowermost row)
                g2.DrawString(FrequencyDistributionX[x - 1].Count.ToString(), DefaultFont, Brushes.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MinY_Win - MaxSize.Height));
            }


            g2.DrawString(DataSetForChart.Count().ToString(), DefaultFont, Brushes.Black, R.viewport_X(x * MaxSize.Width), R.viewport_Y(R.MinY_Win - MaxSize.Height));

            pictureBox1.Image = b2;
        }

        private List<List<int>> generateDatasetMatrix()
        {
            List<List<int>> M = new List<List<int>>();
            // matrix instantiation
            int LengthOfRows = FrequencyDistributionX.Count();
            for (int i = 0; i < FrequencyDistributionY.Count(); i++)
            {
                M.Add(new List<int>(new int[LengthOfRows]));
            }

            // matrix population
            foreach (DataPointForChart DP in DataSetForChart)
            {
                for (int i = 0; i < FrequencyDistributionX.Count(); i++)
                {
                    if (FrequencyDistributionX[i].containsValue(DP.X))
                    {
                        for (int j = 0; j < FrequencyDistributionY.Count(); j++)
                        {
                            if (FrequencyDistributionY[j].containsValue(DP.Y))
                                M[j][i] += 1;
                        }
                    }
                }
            }
            return M;
        }
 */