﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSV_Reader
{
    public partial class Form2 : Form
    {

        public Bitmap contingencyBitmap;
        public Graphics contingencyGraphics;

        public Form2(Dictionary<Tuple<Interval, Interval>, FrequenciesForValue> bivariateDistribution)
        {
            InitializeComponent();

            //init pictureBox1
            contingencyBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            contingencyGraphics = Graphics.FromImage(contingencyBitmap);
            contingencyGraphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            contingencyGraphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            Pen p = new Pen(Brushes.Black, 1.0f);

            // ===================================================================================
            // 1) determinare quanti intervalli in ci sono su X e su Y (righe e colonne)
            List<Interval> listOfIntervals_X = new List<Interval>();
            List<Interval> listOfIntervals_Y = new List<Interval>();
            foreach (KeyValuePair<Tuple<Interval, Interval>, FrequenciesForValue> kvp in bivariateDistribution)
            {
                if (!listOfIntervals_X.Contains(kvp.Key.Item1))
                {
                    listOfIntervals_X.Add(kvp.Key.Item1);
                }

                if (!listOfIntervals_Y.Contains(kvp.Key.Item2))
                {
                    listOfIntervals_Y.Add(kvp.Key.Item2);
                }
            }
            // 2) per ogni intervallo su X disegnare una colonna + la marginal a fine tabella
            foreach(Interval interval_x in listOfIntervals_X)
            {
                //g.DrawLine(p, 0, y * 40, 20 * 40, y * 40);
            }

            // 3) per ogni intervallo su Y disegnare una riga + la marginal a fine tabella
            foreach (Interval interval_y in listOfIntervals_Y)
            {
                //g.DrawLine(p, 0, y * 40, 20 * 40, y * 40);
            }

            // 4) riempire le celle (come ?)

            // ===================================================================================

            this.pictureBox1.Image = contingencyBitmap;
        }

        
    }
}
